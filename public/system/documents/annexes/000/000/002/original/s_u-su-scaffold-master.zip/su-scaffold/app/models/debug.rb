class Debug < ActiveRecord::Base
end
