class HomeController < ApplicationController
  def index
    # sleep 5
  end
end
